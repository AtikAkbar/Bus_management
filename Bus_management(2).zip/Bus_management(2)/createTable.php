<?php
$servername = "localhost:5222";
$username = "root";
$password = "";
$db = "Bus_management";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Corrected SQL statement
// $sql = "CREATE TABLE Driver_Shift (
//     shift_id INT PRIMARY KEY,
//     bus_id INT NOT NULL,
//     user_id INT NOT NULL,
//     shift_start_time TIME NOT NULL,
//     shift_end_time TIME NOT NULL,
//     FOREIGN KEY (bus_id) REFERENCES Bus(bus_id),
//     FOREIGN KEY (user_id) REFERENCES Driver(user_id)
// )";

// $sql = "CREATE TABLE User (
//     user_id INT PRIMARY KEY,          
//     phone VARCHAR(15) NOT NULL,       
//     email VARCHAR(50) NOT NULL,      
//     name VARCHAR(50) NOT NULL         
// )";

// $sql = "CREATE TABLE Passenger (
//     user_id INT PRIMARY KEY,         
//     ticket_status VARCHAR(20) NOT NULL,  
//     FOREIGN KEY (user_id) REFERENCES User(user_id)           
// )";

// $sql = "CREATE TABLE Admin (
//     user_id INT PRIMARY KEY,          
//     FOREIGN KEY (user_id) REFERENCES User(user_id)
    
// )";

// $sql = "CREATE TABLE Bus_BusS_Driver (
//     bus_id INT NOT NULL,             
//     schedule_id INT NOT NULL,       
//     user_id INT NOT NULL,            
//     PRIMARY KEY (bus_id, schedule_id, user_id),
//     FOREIGN KEY (bus_id) REFERENCES Bus(bus_id),
//     FOREIGN KEY (schedule_id) REFERENCES Bus_Schedule(schedule_id),
//     FOREIGN KEY (user_id) REFERENCES User(user_id)
// )";

// $sql = "CREATE TABLE Ticket (
//     ticket_id INT PRIMARY KEY,       
//     price DECIMAL(10, 2) NOT NULL   
// )";

$sql = "CREATE TABLE Specific_Driver (
    user_id INT NOT NULL,            
    specific_driver_id INT PRIMARY KEY,  
    FOREIGN KEY (user_id) REFERENCES User(user_id)
)";
if ($conn->query($sql) === TRUE) {
    echo "Table Bus_Schedule created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>

