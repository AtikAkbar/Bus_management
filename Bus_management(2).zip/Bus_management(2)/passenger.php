<?php
// Database connection
$servername = "localhost:5222";
$username = "root";
$password = "";
$db = "Bus_management";

$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Create, Update, Delete operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        // Collect form data
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $name = $_POST['name'];
        $bus_id = $_POST['bus_id'];
        $travel_date = $_POST['travel_date'];

        // Check if the passenger already exists in Bus_User
        $check_user = "SELECT user_id FROM Bus_User WHERE phone = '$phone' AND email = '$email'";
        $result = $conn->query($check_user);

        if ($result->num_rows > 0) {
            // Passenger exists, get the user_id
            $user = $result->fetch_assoc();
            $user_id = $user['user_id'];
        } else {
            // Insert new passenger into Bus_User
            $sql_user = "INSERT INTO Bus_User (phone, email, name, bus_id) 
                         VALUES ('$phone', '$email', '$name', '$bus_id')";
            $conn->query($sql_user);

            // Get the new user_id
            $user_id = $conn->insert_id;
        }

        // Check if the passenger already has a travel record
        $check_passenger = "SELECT * FROM Passenger WHERE user_id = '$user_id' AND travel_date = '$travel_date'";
        $result_passenger = $conn->query($check_passenger);

        if ($result_passenger->num_rows == 0) {
            // Insert travel details into Passenger table
            $sql_passenger = "INSERT INTO Passenger (user_id, travel_date) 
                              VALUES ('$user_id', '$travel_date')";
            $conn->query($sql_passenger);
        }
    }
    if (isset($_POST['update'])) {
        // Collect form data
        $user_id = $_POST['user_id']; // Primary key to identify the passenger
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $name = $_POST['name'];
        $bus_id = $_POST['bus_id'];
        $travel_date = $_POST['travel_date'];

        // Update the passenger details in Bus_User table
        $sql_user = "UPDATE Bus_User 
                     SET phone = '$phone', email = '$email', name = '$name', bus_id = '$bus_id'
                     WHERE user_id = '$user_id'";
        $conn->query($sql_user);

        // Update the travel details in Passenger table
        $sql_passenger = "UPDATE Passenger 
                          SET travel_date = '$travel_date'
                          WHERE user_id = '$user_id'";
        $conn->query($sql_passenger);
    } elseif (isset($_POST['delete'])) {
        // Delete a passenger
        $user_id = $_POST['user_id'];

        // Delete from Passenger
        $sql_passenger = "DELETE FROM Passenger WHERE user_id='$user_id'";
        $conn->query($sql_passenger);

        // Delete from Bus_User
        $sql_user = "DELETE FROM Bus_User WHERE user_id='$user_id'";
        $conn->query($sql_user);
    }
}

// Fetch all passengers with related details
$sql = "SELECT 
            u.user_id, u.phone, u.email, u.name, 
            p.travel_date, b.bus_number, 
            r.route_name 
        FROM Passenger p
        JOIN Bus_User u ON p.user_id = u.user_id
        JOIN Bus b ON u.bus_id = b.bus_id
        JOIN Bus_Schedule bs ON b.bus_id = bs.bus_id
        JOIN RouteB r ON bs.route_id = r.route_id";

$passengers = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>Passenger Management</title>
</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="d-flex flex-column flex-shrink-0 p-3 text-bg-dark min-vh-100" style="width: 280px">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                <span class="fs-4">Dashboard</span>
            </a>
            <hr>
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="admin.php" class="nav-link text-white">Home</a></li>
                <li><a href="passenger.php" class="nav-link active text-white" aria-current="page">Passenger</a></li>
                <li><a href="driver.php" class="nav-link text-white">Driver</a></li>
                <li><a href="bus.php" class="nav-link text-white">Bus</a></li>
                <li><a href="schedule.php" class="nav-link text-white">Schedule</a></li>
                <li><a href="route.php" class="nav-link text-white">Route</a></li>
            </ul>
            <hr>
        </div>

        <!-- Dashboard Content -->
        <div id="content-wrapper" class="d-flex flex-column flex-grow-1">
            <div class="container-fluid">
                <h1 class="mt-4">Passenger Management</h1>

                <!-- Add Passenger Form -->
                <form method="POST" class="mb-4">
                    <h2>Add / Edit Passenger</h2>
                    <!-- Hidden input for user_id -->
                    <input type="hidden" name="user_id">
                    <div class="row">
                        <div class="col-md-2">
                            <input type="text" name="name" class="form-control" placeholder="Name" required>
                        </div>
                        <div class="col-md-2">
                            <input type="email" name="email" class="form-control" placeholder="Email" required>
                        </div>
                        <div class="col-md-2">
                            <input type="text" name="phone" class="form-control" placeholder="Phone" required>
                        </div>
                        <div class="col-md-2">
                            <select name="bus_id" class="form-control">
                                <?php
                                $buses = $conn->query("SELECT bus_id, bus_number FROM Bus");
                                while ($bus = $buses->fetch_assoc()) {
                                    echo "<option value='{$bus['bus_id']}'>{$bus['bus_number']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <input type="date" name="travel_date" class="form-control" required>
                        </div>
                    </div>
                    <!-- Add and Update buttons -->
                    <button type="submit" name="add" class="btn btn-primary mt-3">Add Passenger</button>
                    <button type="submit" name="update" class="btn btn-success mt-3">Update Passenger</button>
                </form>

                <!-- Passenger Table -->
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Travel Date</th>
                            <th>Bus Number</th>
                            <th>Route</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $passengers->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['user_id'] ?></td>
                                <td><?= $row['name'] ?></td>
                                <td><?= $row['email'] ?></td>
                                <td><?= $row['phone'] ?></td>
                                <td><?= $row['travel_date'] ?></td>
                                <td><?= $row['bus_number'] ?></td>
                                <td><?= $row['route_name'] ?></td>
                                <td>
                                    <!-- Edit Button -->
                                    <button type="button" class="btn btn-sm btn-warning"
                                        onclick="fillForm(<?= htmlspecialchars(json_encode($row)) ?>)">Edit</button>
                                    <!-- Delete Button -->
                                    <form method="POST" style="display: inline-block">
                                        <input type="hidden" name="user_id" value="<?= $row['user_id'] ?>">
                                        <button type="submit" name="delete" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function fillForm(data) {
            // Populate the form fields with the selected passenger's data
            document.querySelector('input[name="user_id"]').value = data.user_id;
            document.querySelector('input[name="name"]').value = data.name;
            document.querySelector('input[name="email"]').value = data.email;
            document.querySelector('input[name="phone"]').value = data.phone;
            document.querySelector('select[name="bus_id"]').value = data.bus_id;
            document.querySelector('input[name="travel_date"]').value = data.travel_date;
        }
    </script>
</body>

</html>