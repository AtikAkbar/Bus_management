<?php
// Database connection
$servername = "localhost:5222";
$username = "root";
$password = "";
$db = "Bus_management";

$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Create, Update, Delete operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        // Add a new schedule
        $bus_id = $_POST['bus_id'];
        $route_id = $_POST['route_id'];
        $departure_time = $_POST['departure_time'];
        $arrival_time = $_POST['arrival_time'];
        $trip_duration = $_POST['trip_duration'];

        $sql = "INSERT INTO Bus_Schedule (bus_id, route_id, departure_time, arrival_time, trip_duration) 
                VALUES ('$bus_id', '$route_id', '$departure_time', '$arrival_time', '$trip_duration')";
        $conn->query($sql);
    } elseif (isset($_POST['update'])) {
        // Update an existing schedule
        $schedule_id = $_POST['schedule_id'];
        $bus_id = $_POST['bus_id'];
        $route_id = $_POST['route_id'];
        $departure_time = $_POST['departure_time'];
        $arrival_time = $_POST['arrival_time'];
        $trip_duration = $_POST['trip_duration'];

        $sql = "UPDATE Bus_Schedule 
                SET bus_id = '$bus_id', route_id = '$route_id', departure_time = '$departure_time', 
                    arrival_time = '$arrival_time', trip_duration = '$trip_duration'
                WHERE schedule_id = '$schedule_id'";
        $conn->query($sql);
    } elseif (isset($_POST['delete'])) {
        // Delete a schedule
        $schedule_id = $_POST['schedule_id'];

        $sql = "DELETE FROM Bus_Schedule WHERE schedule_id='$schedule_id'";
        $conn->query($sql);
    }
}

// Fetch all schedules
$sql = "SELECT 
            bs.schedule_id, b.bus_number, r.route_name, bs.departure_time, 
            bs.arrival_time, bs.trip_duration 
        FROM Bus_Schedule bs
        JOIN Bus b ON bs.bus_id = b.bus_id
        JOIN RouteB r ON bs.route_id = r.route_id
        ORDER BY bs.schedule_id ASC"; // Add this ORDER BY clause


$schedules = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>Schedule Management</title>
</head>

<body>
    <div class="container mt-4">
        <h1>Bus Schedule Management</h1>

        <!-- Add / Edit Schedule Form -->
        <form method="POST" class="mb-4">
            <h2>Add / Edit Schedule</h2>
            <!-- Hidden input for schedule_id -->
            <input type="hidden" name="schedule_id">
            <div class="row">
                <div class="col-md-2">
                    <select name="bus_id" class="form-control" required>
                        <option value="" disabled selected>Select Bus</option>
                        <?php
                        $buses = $conn->query("SELECT bus_id, bus_number FROM Bus");
                        while ($bus = $buses->fetch_assoc()) {
                            echo "<option value='{$bus['bus_id']}'>{$bus['bus_number']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="route_id" class="form-control" required>
                        <option value="" disabled selected>Select Route</option>
                        <?php
                        $routes = $conn->query("SELECT route_id, route_name FROM RouteB");
                        while ($route = $routes->fetch_assoc()) {
                            echo "<option value='{$route['route_id']}'>{$route['route_name']}</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <input type="time" name="departure_time" class="form-control" placeholder="Departure Time" required>
                </div>
                <div class="col-md-2">
                    <input type="time" name="arrival_time" class="form-control" placeholder="Arrival Time" required>
                </div>
                <div class="col-md-2">
                    <input type="text" name="trip_duration" class="form-control" placeholder="Trip Duration (e.g., 2h 30m)" required>
                </div>
            </div>
            <!-- Add and Update buttons -->
            <button type="submit" name="add" class="btn btn-primary mt-3">Add Schedule</button>
            <button type="submit" name="update" class="btn btn-success mt-3">Update Schedule</button>
        </form>

        <!-- Schedule Table -->
        <table class="table table-striped table-bordered">
            <thead>
                <tr>
                    <th>Schedule ID</th>
                    <th>Bus Number</th>
                    <th>Route</th>
                    <th>Departure Time</th>
                    <th>Arrival Time</th>
                    <th>Trip Duration</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $schedules->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['schedule_id'] ?></td>
                        <td><?= $row['bus_number'] ?></td>
                        <td><?= $row['route_name'] ?></td>
                        <td><?= $row['departure_time'] ?></td>
                        <td><?= $row['arrival_time'] ?></td>
                        <td><?= $row['trip_duration'] ?></td>
                        <td>
                            <!-- Edit Button -->
                            <button type="button" class="btn btn-sm btn-warning"
                                onclick="fillForm(<?= htmlspecialchars(json_encode($row)) ?>)">Edit</button>
                            <!-- Delete Button -->
                            <form method="POST" style="display: inline-block">
                                <input type="hidden" name="schedule_id" value="<?= $row['schedule_id'] ?>">
                                <button type="submit" name="delete" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        function fillForm(data) {
            // Populate the form fields with the selected schedule's data
            document.querySelector('input[name="schedule_id"]').value = data.schedule_id;
            document.querySelector('select[name="bus_id"]').value = data.bus_id;
            document.querySelector('select[name="route_id"]').value = data.route_id;
            document.querySelector('input[name="departure_time"]').value = data.departure_time;
            document.querySelector('input[name="arrival_time"]').value = data.arrival_time;
            document.querySelector('input[name="trip_duration"]').value = data.trip_duration;
        }
    </script>
</body>

</html>
