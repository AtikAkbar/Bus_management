<?php
// Database connection
include("connectDB.php");




// Handle Create, Update, Delete operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add'])) {
        // Add a new bus
        $bus_number = $_POST['bus_number'];
        $capacity = $_POST['capacity'];
        $bus_type = $_POST['bus_type'];
        $manufacturer = $_POST['manufacturer'];
        $status = $_POST['status'];
        $purchase_date = $_POST['purchase_date'];

        $sql = "INSERT INTO bus (bus_number, capacity, bus_type, manufacturer, status, purchase_date) 
                VALUES ('$bus_number', '$capacity', '$bus_type', '$manufacturer', '$status', '$purchase_date')";
        $conn->query($sql);
    } elseif (isset($_POST['update'])) {
        // Update bus details
        $bus_id = $_POST['bus_id'];
        $bus_number = $_POST['bus_number'];
        $capacity = $_POST['capacity'];
        $bus_type = $_POST['bus_type'];
        $manufacturer = $_POST['manufacturer'];
        $status = $_POST['status'];
        $purchase_date = $_POST['purchase_date'];

        $sql = "UPDATE bus 
                SET bus_number='$bus_number', capacity='$capacity', bus_type='$bus_type', 
                    manufacturer='$manufacturer', status='$status', purchase_date='$purchase_date'
                WHERE bus_id='$bus_id'";
        $conn->query($sql);
    } elseif (isset($_POST['delete'])) {
        // Delete a bus
        $bus_id = $_POST['bus_id'];
        $sql = "DELETE FROM bus WHERE bus_id='$bus_id'";
        $conn->query($sql);
    }
}

// Fetch all bus
$bus = $conn->query("SELECT * FROM bus");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <title>Bus Management</title>
</head>

<body>
    <div class="d-flex" id="wrapper">
        <!-- Sidebar -->
        <div class="d-flex flex-column flex-shrink-0 p-3 text-bg-dark min-vh-100" style="width: 280px">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                <span class="fs-4">Dashboard</span>
            </a>
            <hr>
            <ul class="nav nav-pills flex-column mb-auto">
                <li><a href="admin.php" class="nav-link text-white">Home</a></li>
                <li><a href="passenger.php" class="nav-link text-white">Passenger</a></li>
                <li><a href="driver.php" class="nav-link text-white">Driver</a></li>
                <li><a href="bus.php" class="nav-link active text-white" aria-current="page">Bus</a></li>
                <li><a href="#" class="nav-link text-white">Schedule</a></li>
                <li><a href="#" class="nav-link text-white">Route</a></li>
            </ul>
            <hr>
        </div>

        <!-- Dashboard Content -->
        <div id="content-wrapper" class="d-flex flex-column flex-grow-1">
            <div class="container-fluid">
                <h1 class="mt-4">Bus Management</h1>

                <!-- Add Bus Form -->
                <form method="POST" class="mb-4">
                    <h2>Add / Edit Bus</h2>
                    <!-- Hidden input for bus_id -->
                    <input type="hidden" name="bus_id">
                    <div class="row">
                        <div class="col-md-2">
                            <input type="text" name="bus_number" class="form-control" placeholder="Bus Number" required>
                        </div>
                        <div class="col-md-2">
                            <input type="number" name="capacity" class="form-control" placeholder="Capacity" required>
                        </div>
                        <div class="col-md-2">
                            <input type="text" name="bus_type" class="form-control" placeholder="Bus Type" required>
                        </div>
                        <div class="col-md-2">
                            <input type="text" name="manufacturer" class="form-control" placeholder="Manufacturer"
                                required>
                        </div>
                        <div class="col-md-2">
                            <select name="status" class="form-control">
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <input type="date" name="purchase_date" class="form-control" required>
                        </div>
                    </div>
                    <!-- Add and Update buttons -->
                    <button type="submit" name="add" class="btn btn-primary mt-3">Add Bus</button>
                    <button type="submit" name="update" class="btn btn-success mt-3">Update Bus</button>
                </form>


                <!-- Bus Table -->
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Bus ID</th>
                            <th>Bus Number</th>
                            <th>Capacity</th>
                            <th>Bus Type</th>
                            <th>Manufacturer</th>
                            <th>status</th>
                            <th>Purchase Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $bus->fetch_assoc()): ?>
                            <tr>
                                <td><?= $row['bus_id'] ?></td>
                                <td><?= $row['bus_number'] ?></td>
                                <td><?= $row['capacity'] ?></td>
                                <td><?= $row['bus_type'] ?></td>
                                <td><?= $row['manufacturer'] ?></td>
                                <td><?= $row['status'] ?></td>
                                <td><?= $row['purchase_date'] ?></td>
                                <td>
                                    <!-- Edit Button -->
                                    <button type="button" class="btn btn-sm btn-warning"
                                        onclick="fillForm(<?= htmlspecialchars(json_encode($row)) ?>)">Edit</button>
                                    <!-- Delete Button -->
                                    <form method="POST" style="display: inline-block">
                                        <input type="hidden" name="bus_id" value="<?= $row['bus_id'] ?>">
                                        <button type="submit" name="delete" class="btn btn-sm btn-danger">Delete</button>
                                    </form>
                                </td>

                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function fillForm(data) {
            // Populate the form fields with the selected bus's data
            document.querySelector('input[name="bus_id"]').value = data.bus_id; // Hidden field for bus_id
            document.querySelector('input[name="bus_number"]').value = data.bus_number;
            document.querySelector('input[name="capacity"]').value = data.capacity;
            document.querySelector('input[name="bus_type"]').value = data.bus_type;
            document.querySelector('input[name="manufacturer"]').value = data.manufacturer;
            document.querySelector('select[name="status"]').value = data.status;
            document.querySelector('input[name="purchase_date"]').value = data.purchase_date;
        }

    </script>

</body>

</html>