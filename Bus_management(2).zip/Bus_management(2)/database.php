<?php
$servername = "localhost:5222";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if database exists
$dbName = "bus_management";
$sql = "SHOW DATABASES LIKE '$dbName'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "Database '$dbName' already exists.";
} else {
    // Create database
    $sql = "CREATE DATABASE $bus_management";
    if ($conn->query($sql) === TRUE) {
        echo "Database created successfully";
    } else {
        echo "Error creating database: " . $conn->error;
    }
}

$conn->close();
?>
