<?php
$servername = "localhost:5222";
$username = "root";
$password = "";
$db = "Bus_management";

// Create connection
$conn = new mysqli($servername, $username, $password, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO Bus (bus_id, bus_number, capacity, bus_type, manufacturer, status, purchase_date)
VALUES
(10, 'AB-1234', 50, 'AC', 'Volvo', 'Active', '2018-05-10')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }

$conn->close();
?>
